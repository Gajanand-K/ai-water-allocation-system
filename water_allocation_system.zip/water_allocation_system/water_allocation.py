"""
AI-Based Water Allocation and Shortage Prediction System
Water Allocation & Shortage Management Engine

Calculates:
1. Predicted Water Demand using trained Random Forest model
2. Shortage = Predicted Water Demand - Available Water
3. Shortage Status:
   - shortage <= 0         -> "Sufficient"
   - 0 < shortage <= 200000 -> "Moderate Shortage"
   - shortage > 200000     -> "High Shortage"
4. Recommended Water Allocation across all 10 areas using regional surplus redistribution.
"""

import os
import joblib
import pandas as pd
import numpy as np

MODEL_PATH = "model/water_demand_rf.joblib"
DATA_PATH = "data/water_data.csv"

# Global model cache
_cached_model = None


def get_model():
    """Load and cache the trained Random Forest model."""
    global _cached_model
    if _cached_model is None:
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(f"Trained model not found at {MODEL_PATH}. Train the model first.")
        _cached_model = joblib.load(MODEL_PATH)
    return _cached_model


def get_shortage_status(shortage):
    """
    Classify shortage according to project requirements:
    - shortage <= 0         -> 'Sufficient'
    - 0 < shortage <= 200000 -> 'Moderate Shortage'
    - shortage > 200000     -> 'High Shortage'
    """
    if shortage <= 0:
        return {
            "status": "Sufficient",
            "code": "sufficient",
            "color": "#10b981",       # Emerald green
            "badge_class": "badge-sufficient",
            "description": "Available water meets or exceeds predicted demand."
        }
    elif shortage <= 200000:
        return {
            "status": "Moderate Shortage",
            "code": "moderate",
            "color": "#f59e0b",       # Amber
            "badge_class": "badge-moderate",
            "description": "Deficit up to 200,000 Liters. Can be managed via local buffer or small transfer."
        }
    else:
        return {
            "status": "High Shortage",
            "code": "high",
            "color": "#ef4444",       # Rose / Red
            "badge_class": "badge-high",
            "description": "Critical deficit exceeding 200,000 Liters. Priority regional allocation needed."
        }


def predict_single(area_name, population, rainfall, temperature, available_water):
    """
    Make AI prediction for a single area:
    Inputs: population, rainfall, temperature, available_water
    Predicts: water_demand
    Calculates: shortage = predicted water demand - available water
    Returns: dictionary with all computed results and status
    """
    model = get_model()
    
    input_df = pd.DataFrame([{
        "population": float(population),
        "rainfall": float(rainfall),
        "temperature": float(temperature),
        "available_water": float(available_water)
    }])
    
    predicted_demand = int(round(float(model.predict(input_df)[0])))
    shortage = predicted_demand - int(available_water)
    status_info = get_shortage_status(shortage)
    
    demand_coverage_pct = round((float(available_water) / predicted_demand * 100), 1) if predicted_demand > 0 else 100.0
    
    return {
        "area": area_name,
        "population": int(population),
        "rainfall": float(rainfall),
        "temperature": float(temperature),
        "available_water": int(available_water),
        "predicted_demand": predicted_demand,
        "shortage": shortage,
        "status": status_info["status"],
        "status_code": status_info["code"],
        "status_color": status_info["color"],
        "badge_class": status_info["badge_class"],
        "status_description": status_info["description"],
        "coverage_percent": demand_coverage_pct
    }


def compute_allocation_plan(custom_areas_data=None):
    """
    Compute comprehensive water allocation for all 10 areas.
    If custom_areas_data is provided (list of dicts), use it.
    Otherwise, load the latest snapshot for all 10 areas from data/water_data.csv.
    
    Returns:
    - areas_table: List of area records with available water, predicted demand, shortage, recommended allocation, status
    - summary: Overall regional water metrics
    """
    model = get_model()
    
    if custom_areas_data is None:
        # Load latest date snapshot from dataset
        df = pd.read_csv(DATA_PATH)
        latest_date = df["date"].max()
        snapshot_df = df[df["date"] == latest_date].copy()
    else:
        snapshot_df = pd.DataFrame(custom_areas_data)
        latest_date = "Custom Scenario"
        
    records = []
    
    # Step 1: Predict demand and initial shortage for each area
    for _, row in snapshot_df.iterrows():
        area_name = str(row["area"])
        pop = int(row["population"])
        rain = float(row["rainfall"])
        temp = float(row["temperature"])
        avail = int(row["available_water"])
        
        # Predict using Random Forest
        feat_df = pd.DataFrame([{
            "population": float(pop),
            "rainfall": float(rain),
            "temperature": float(temp),
            "available_water": float(avail)
        }])
        pred_demand = int(round(float(model.predict(feat_df)[0])))
        shortage = pred_demand - avail
        status_info = get_shortage_status(shortage)
        
        records.append({
            "area": area_name,
            "population": pop,
            "rainfall": rain,
            "temperature": temp,
            "available_water": avail,
            "predicted_demand": pred_demand,
            "shortage": shortage,
            "status": status_info["status"],
            "status_code": status_info["code"],
            "status_color": status_info["color"],
            "badge_class": status_info["badge_class"],
            # Initial metrics
            "initial_surplus": max(0, -shortage),
            "initial_deficit": max(0, shortage)
        })
        
    total_avail = sum(r["available_water"] for r in records)
    total_demand = sum(r["predicted_demand"] for r in records)
    total_deficit = sum(r["initial_deficit"] for r in records)
    total_surplus = sum(r["initial_surplus"] for r in records)
    net_shortage = total_demand - total_avail
    
    # Step 2: Regional Allocation Strategy
    # Surplus areas retain their demand + 2% contingency buffer. Excess water
    # enters the regional transfer pool for deficit areas.
    # Deficit areas receive a proportional share based on their deficit size.
    
    transfer_pool = 0
    for r in records:
        if r["shortage"] <= 0:
            # Surplus area: needs predicted_demand
            contingency = int(r["predicted_demand"] * 0.02)
            retained = min(r["available_water"], r["predicted_demand"] + contingency)
            transferrable = max(0, r["available_water"] - retained)
            transfer_pool += transferrable
            r["transferrable"] = transferrable
            r["retained"] = retained
        else:
            r["transferrable"] = 0
            r["retained"] = r["available_water"]
            
    # Step 3: Distribute transfer_pool to deficit areas
    for r in records:
        if r["shortage"] <= 0:
            # Surplus area allocation is its retained water (full demand met + buffer)
            r["recommended_allocation"] = r["retained"]
            r["post_shortage"] = r["predicted_demand"] - r["recommended_allocation"]
            r["allocation_note"] = f"Self-Sufficient (Supplies {r['transferrable']:,} L to grid)" if r['transferrable'] > 0 else "Self-Sufficient"
        else:
            # Deficit area gets its available water PLUS a proportional or prioritized share of the transfer pool
            if total_deficit > 0 and transfer_pool > 0:
                deficit_fraction = r["initial_deficit"] / total_deficit
                transferred_in = int(round(min(r["initial_deficit"], transfer_pool * deficit_fraction)))
            else:
                transferred_in = 0
                
            r["recommended_allocation"] = r["available_water"] + transferred_in
            r["post_shortage"] = r["predicted_demand"] - r["recommended_allocation"]
            
            if transferred_in >= r["initial_deficit"]:
                r["allocation_note"] = f"Deficit completely cleared (+{transferred_in:,} L transfer)"
            elif transferred_in > 0:
                r["allocation_note"] = f"Relieved with +{transferred_in:,} L transfer"
            else:
                r["allocation_note"] = "Supplied from local reservoir only"
                
        # Post-allocation status
        post_status = get_shortage_status(r["post_shortage"])
        r["post_status"] = post_status["status"]
        r["post_badge_class"] = post_status["badge_class"]
        
    summary = {
        "date": latest_date,
        "total_population": sum(r["population"] for r in records),
        "total_available_water": total_avail,
        "total_predicted_demand": total_demand,
        "total_shortage": net_shortage,
        "total_deficit": total_deficit,
        "total_surplus": total_surplus,
        "water_transferred": sum(r["recommended_allocation"] - r["available_water"] for r in records if r["recommended_allocation"] > r["available_water"]),
        "status_breakdown": {
            "sufficient": sum(1 for r in records if r["status"] == "Sufficient"),
            "moderate": sum(1 for r in records if r["status"] == "Moderate Shortage"),
            "high": sum(1 for r in records if r["status"] == "High Shortage")
        },
        "post_status_breakdown": {
            "sufficient": sum(1 for r in records if r["post_status"] == "Sufficient"),
            "moderate": sum(1 for r in records if r["post_status"] == "Moderate Shortage"),
            "high": sum(1 for r in records if r["post_status"] == "High Shortage")
        },
        "disclaimer": "Dataset is synthetically generated for project demonstration."
    }
    
    return records, summary


if __name__ == "__main__":
    records, summary = compute_allocation_plan()
    print("=== Water Allocation Plan Sample ===")
    print(f"Total Available: {summary['total_available_water']:,} L")
    print(f"Total Demand:    {summary['total_predicted_demand']:,} L")
    print(f"Net Shortage:    {summary['total_shortage']:,} L")
    print("First 3 areas:")
    for r in records[:3]:
        print(f" - {r['area']}: Avail={r['available_water']:,} | Demand={r['predicted_demand']:,} | Shortage={r['shortage']:,} [{r['status']}] -> Rec. Alloc={r['recommended_allocation']:,}")
