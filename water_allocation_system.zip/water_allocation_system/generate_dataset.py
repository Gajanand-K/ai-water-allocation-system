"""
AI-Based Water Allocation and Shortage Prediction System
Synthetic Dataset Generator

NOTE: Dataset is synthetically generated for project demonstration.
Generates 3,650 rows (10 areas x 365 days).
Columns: date, area, population, rainfall, temperature, available_water, water_demand, shortage
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

DISCLAIMER_NOTE = "Dataset is synthetically generated for project demonstration."

AREAS_CONFIG = [
    {"name": "North Hills", "base_pop": 38000, "base_avail": 5200000, "temp_offset": -2.5, "rain_factor": 1.25},
    {"name": "South Valley", "base_pop": 76000, "base_avail": 9800000, "temp_offset": 1.0, "rain_factor": 0.95},
    {"name": "East Riverside", "base_pop": 92000, "base_avail": 13200000, "temp_offset": 0.0, "rain_factor": 1.10},
    {"name": "West Plain", "base_pop": 64000, "base_avail": 7800000, "temp_offset": 2.5, "rain_factor": 0.70},
    {"name": "Central Metro", "base_pop": 128000, "base_avail": 16500000, "temp_offset": 1.5, "rain_factor": 0.90},
    {"name": "Greenfield", "base_pop": 45000, "base_avail": 6300000, "temp_offset": -0.5, "rain_factor": 1.05},
    {"name": "Lakeview", "base_pop": 58000, "base_avail": 8600000, "temp_offset": -1.0, "rain_factor": 1.15},
    {"name": "Highland Park", "base_pop": 51000, "base_avail": 6900000, "temp_offset": -2.0, "rain_factor": 1.20},
    {"name": "Sunset Coast", "base_pop": 85000, "base_avail": 11400000, "temp_offset": 0.5, "rain_factor": 1.00},
    {"name": "Riverdale Basin", "base_pop": 70000, "base_avail": 9600000, "temp_offset": -0.5, "rain_factor": 1.10},
]


def generate_water_dataset(output_path="data/water_data.csv", start_date="2025-01-01"):
    """Generate 3650 rows of realistic synthetic water data for 10 areas over 365 days."""
    np.random.seed(42)
    start_dt = datetime.strptime(start_date, "%Y-%m-%d")
    
    rows = []
    
    # 365 days
    for day in range(365):
        current_date = (start_dt + timedelta(days=day)).strftime("%Y-%m-%d")
        
        # Day of year normalized for seasonal climate simulation
        doy = day % 365
        
        # Base seasonal temperature (warmer in mid-year / summer around day 130-170 in northern hemisphere)
        # Using a smooth cycle: cold winter (Jan ~20C), peak summer (May-Jun ~38C), monsoon (Jul-Aug ~30C), autumn (Sep-Nov ~27C)
        seasonal_temp_base = 28.0 + 10.0 * np.sin(2 * np.pi * (doy - 60) / 365)
        
        # Seasonal monsoon rainfall probability: highest between day 160 and 260
        monsoon_intensity = np.exp(-((doy - 210) ** 2) / (2 * (35 ** 2)))
        
        for area_info in AREAS_CONFIG:
            area_name = area_info["name"]
            
            # 1. Population: base with slight annual progression and small noise
            pop_growth = 1.0 + (day / 365.0) * 0.015  # 1.5% annual growth
            pop_noise = np.random.normal(0, 150)
            population = int(area_info["base_pop"] * pop_growth + pop_noise)
            
            # 2. Temperature (Celsius)
            temp_noise = np.random.normal(0, 1.2)
            temperature = round(float(seasonal_temp_base + area_info["temp_offset"] + temp_noise), 1)
            # Ensure within realistic human-habitat range [12C, 45C]
            temperature = max(12.0, min(45.0, temperature))
            
            # 3. Rainfall (mm)
            # Rain occurrence has higher probability during monsoon
            rain_prob = 0.08 + 0.65 * monsoon_intensity * area_info["rain_factor"]
            if np.random.rand() < rain_prob:
                # Gamma distribution for rainfall amounts
                rain_amount = np.random.gamma(shape=2.5, scale=6.0) * area_info["rain_factor"]
                rainfall = round(float(min(140.0, max(0.5, rain_amount))), 1)
            else:
                rainfall = 0.0
                
            # 4. Water Demand (Liters)
            # Realistic per-capita usage: base ~130 L/person/day
            # High temperatures increase demand (drinking, cooling, showers, watering): +1.8% per °C above 25°C
            temp_factor = 1.0 + 0.018 * (temperature - 25.0)
            
            # Rainfall decreases external demand (gardening, car washing): -0.4% per mm, capped at -20%
            rain_reduction = min(0.20, (rainfall * 0.004))
            
            # Base per capita requirement: ~135 L/person/day
            per_capita_rate = 135.0 + np.random.normal(0, 2.0)
            commercial_demand = population * 14.0
            
            # Weekend / weekday variation
            day_of_week = (start_dt + timedelta(days=day)).weekday()
            day_multiplier = 1.03 if day_of_week in [5, 6] else 1.0
            
            # Water demand strictly driven by human usage and climate
            raw_demand = (population * per_capita_rate * temp_factor * (1.0 - rain_reduction) * day_multiplier) + commercial_demand
            water_demand = int(round(raw_demand))
            
            # 5. Available Water (Liters)
            # Driven by area infrastructure capacity, reservoir baseline, rainfall recharge, and evaporation
            # Some areas have ample water reserves, others face structural deficits
            summer_stress = max(0.0, (temperature - 28.0) / 16.0) * 0.18
            monsoon_recharge = (monsoon_intensity * 0.20 + (rainfall / 100.0) * 0.15) * area_info["rain_factor"]
            daily_weather_noise = np.random.normal(0, 0.02)
            
            # Capacity factor fluctuates seasonally
            capacity_factor = 1.0 - summer_stress + monsoon_recharge + daily_weather_noise
            
            # Area baseline storage designed so some areas have surplus, some moderate stress, some high stress
            area_storage_multiplier = {
                "North Hills": 0.985,     # 38k pop, demand ~5.7M -> deficit ~85k (Moderate)
                "South Valley": 0.985,    # 76k pop -> summer high shortage, moderate in spring/fall
                "East Riverside": 1.08,   # surplus / sufficient
                "West Plain": 0.94,       # dry zone, high shortage
                "Central Metro": 0.95,    # high density, high shortage
                "Greenfield": 1.05,       # sufficient
                "Lakeview": 1.09,         # reservoir hub, mostly sufficient
                "Highland Park": 0.982,   # 51k pop, deficit ~100k (Moderate)
                "Sunset Coast": 0.995,    # 85k pop, balanced / moderate shortage (~50k to 150k)
                "Riverdale Basin": 0.988  # 70k pop, moderate shortage (~90k to 180k)
            }.get(area_name, 1.00)
            
            # Baseline expected demand for this area
            typical_area_demand = area_info["base_pop"] * 152.0
            available_base = typical_area_demand * area_storage_multiplier * capacity_factor
            
            # Add stochastic supply variation
            available_water = int(round(max(1500000, available_base + np.random.normal(0, 45000.0))))
            
            # 6. Shortage (Liters)
            # shortage = water_demand - available_water
            shortage = water_demand - available_water
            
            rows.append({
                "date": current_date,
                "area": area_name,
                "population": population,
                "rainfall": rainfall,
                "temperature": temperature,
                "available_water": available_water,
                "water_demand": water_demand,
                "shortage": shortage
            })
            
    df = pd.DataFrame(rows)
    
    # Verify row count
    assert len(df) == 3650, f"Expected 3650 rows, got {len(df)}"
    assert len(df["area"].unique()) == 10, f"Expected 10 areas, got {len(df['area'].unique())}"
    
    # Save CSV
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    
    print(f"Generated synthetic dataset successfully at {output_path}")
    print(f"Total rows: {len(df)} | Columns: {list(df.columns)}")
    print(f"Note: {DISCLAIMER_NOTE}")
    print(f"Shortage stats: Min={df['shortage'].min()}, Median={df['shortage'].median()}, Max={df['shortage'].max()}")
    
    return df


if __name__ == "__main__":
    generate_water_dataset()
