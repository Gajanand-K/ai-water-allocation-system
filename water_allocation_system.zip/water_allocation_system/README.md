# AI-Based Water Allocation and Shortage Prediction System

> **College Project Submission**  
> *Academic Disclaimer: Dataset is synthetically generated for project demonstration.*

---

## 📌 Project Overview
This project presents an intelligent decision support system designed to predict municipal water demand, identify potential water deficits, and compute equitable water allocations across regional sectors using machine learning.

---

## 📊 Dataset Specification
* **Total Observations:** Exactly 3,650 rows
* **Time Span:** 365 daily cycles
* **Areas:** 10 municipal sectors:
  1. North Hills
  2. South Valley
  3. East Riverside
  4. West Plain
  5. Central Metro
  6. Greenfield
  7. Lakeview
  8. Highland Park
  9. Sunset Coast
  10. Riverdale Basin
* **Columns:**
  - `date`: Daily timestamp (YYYY-MM-DD)
  - `area`: Sector name
  - `population`: Resident population count
  - `rainfall`: Daily precipitation (mm)
  - `temperature`: Daily ambient temperature (°C)
  - `available_water`: Local reservoir storage (Liters)
  - `water_demand`: Daily consumption requirement (Liters)
  - `shortage`: Water deficit or surplus (Liters)

---

## 🧠 Machine Learning Model
* **Algorithm:** Random Forest Regression (`sklearn.ensemble.RandomForestRegressor`)
* **Inputs (Features):**
  - `population`
  - `rainfall`
  - `temperature`
  - `available_water`
* **Prediction Target:**
  - `water_demand`
* **Shortage Equation:**
  $$\text{shortage} = \text{predicted water demand} - \text{available water}$$
* **Status Classification Logic:**
  - $\text{shortage} \le 0 \implies$ **Sufficient** (Supply covers demand)
  - $0 < \text{shortage} \le 200,000 \implies$ **Moderate Shortage**
  - $\text{shortage} > 200,000 \implies$ **High Shortage** (Critical stress)

---

## 🌐 Website Sections
1. **Dashboard:**
   - Regional KPIs (Total Population, Available Water, Total Demand, Net Shortage)
   - Interactive charts:
     - Area-wise Available Water vs Water Demand (Bar chart)
     - Shortage Status Distribution (Donut chart)
     - 30-Day Seasonal Demand & Available Water Trend (Line chart)
2. **AI Prediction:**
   - Area selector for the 10 monitored sectors
   - Interactive parameter adjustment (population, rainfall, temperature, available water)
   - Climate scenario quick-presets (Normal Day, Heatwave, Heavy Rain, Drought)
   - Real-time demand prediction, shortage calculation, and status badge
   - Visual demand-supply coverage progress meter
3. **Water Allocation:**
   - 10-Area water allocation matrix
   - Evaluates each area's available water, predicted demand, shortage, and status
   - Computes intelligent **Recommended Allocation** reallocating surplus to deficit areas
   - CSV export for project documentation and grading

---

## 🛠️ Technology Stack
* **Backend:** Python 3.11, Flask
* **Machine Learning & Data:** Scikit-learn, Pandas, NumPy, Joblib
* **Frontend:** HTML5, CSS3 (Aquatic Water Theme), JavaScript, Chart.js, FontAwesome

---

## 🚀 How to Run the Website
1. Double-click `run.bat` or run in terminal:
   ```powershell
   .\.venv\Scripts\python.exe app.py
   ```
2. Open your browser and navigate to:
   ```
   http://127.0.0.1:5000
   ```

3. To run the automated verification test suite:
   ```powershell
   .\.venv\Scripts\python.exe test_app.py
   ```

---
*Notice: Dataset is synthetically generated for project demonstration.*
