@echo off
title AI-Based Water Allocation and Shortage Prediction System
echo ======================================================================
echo AI-Based Water Allocation and Shortage Prediction System (College Project)
echo ======================================================================
echo.
echo Dataset is synthetically generated for project demonstration.
echo.
echo Starting Flask web server...
echo Access the website at: http://127.0.0.1:5000
echo.
".venv\Scripts\python.exe" app.py
pause
