"""
AI-Based Water Allocation and Shortage Prediction System
Flask Web Application

College Project
Features:
1. Dashboard with KPI cards and interactive Chart.js charts
2. AI Prediction using Random Forest Regressor
3. Water Allocation engine across 10 areas
"""

import os
import json
import pandas as pd
import numpy as np
from flask import Flask, render_template, request, jsonify

from generate_dataset import generate_water_dataset, DISCLAIMER_NOTE
from train_model import train_model, FEATURE_COLS, TARGET_COL, classify_shortage
from water_allocation import get_model, predict_single, compute_allocation_plan, get_shortage_status

app = Flask(__name__)

DATA_PATH = "data/water_data.csv"
MODEL_PATH = "model/water_demand_rf.joblib"
METRICS_PATH = "model/model_metrics.json"


def ensure_data_and_model():
    """Ensure dataset and model exist upon starting the web application."""
    if not os.path.exists(DATA_PATH):
        print("Dataset not found. Generating synthetic dataset...")
        generate_water_dataset(DATA_PATH)
        
    if not os.path.exists(MODEL_PATH):
        print("Trained model not found. Training Random Forest model...")
        train_model()


@app.route("/")
def index():
    """Main single-page application with Dashboard, AI Prediction, and Water Allocation sections."""
    return render_template("index.html", disclaimer=DISCLAIMER_NOTE)


@app.route("/api/dashboard_data")
def api_dashboard_data():
    """API providing data for Dashboard KPIs and charts."""
    df = pd.read_csv(DATA_PATH)
    latest_date = df["date"].max()
    latest_df = df[df["date"] == latest_date].copy()
    
    # Load the trained Random Forest once. Dashboard demand and shortage values
    # must come from the same AI model used by the Prediction and Allocation pages.
    model = get_model()

    def add_ai_predictions(frame):
        frame = frame.copy()
        features = frame[["population", "rainfall", "temperature", "available_water"]].astype(float)
        frame["predicted_demand"] = np.rint(model.predict(features)).astype(int)
        frame["predicted_shortage"] = frame["predicted_demand"] - frame["available_water"]
        return frame

    latest_df = add_ai_predictions(latest_df)

    # 1. KPIs for the latest day — based on AI predictions
    total_pop = int(latest_df["population"].sum())
    total_avail = int(latest_df["available_water"].sum())
    total_demand = int(latest_df["predicted_demand"].sum())
    total_shortage = int(latest_df["predicted_shortage"].sum())

    # 2. Area-wise breakdown for bar chart — AI-predicted demand/shortage
    areas_list = latest_df["area"].tolist()
    available_by_area = latest_df["available_water"].astype(int).tolist()
    demand_by_area = latest_df["predicted_demand"].astype(int).tolist()
    shortage_by_area = latest_df["predicted_shortage"].astype(int).tolist()

    # 3. Overall AI shortage distribution across the complete dataset
    predicted_df = add_ai_predictions(df)
    s = predicted_df["predicted_shortage"]
    sufficient_cnt = int((s <= 0).sum())
    moderate_cnt = int(((s > 0) & (s <= 200000)).sum())
    high_cnt = int((s > 200000).sum())

    # 4. 30-Day Trend — available water versus AI-predicted demand
    unique_dates = sorted(df["date"].unique())[-30:]
    trend_source = predicted_df[predicted_df["date"].isin(unique_dates)]
    trend_df = trend_source.groupby("date").agg({
        "available_water": "sum",
        "predicted_demand": "sum",
        "rainfall": "mean",
        "temperature": "mean"
    }).reset_index()

    trend_data = {
        "dates": trend_df["date"].tolist(),
        "available_water": trend_df["available_water"].astype(int).tolist(),
        "water_demand": trend_df["predicted_demand"].astype(int).tolist(),
        "rainfall": [round(float(r), 1) for r in trend_df["rainfall"].tolist()],
        "temperature": [round(float(t), 1) for t in trend_df["temperature"].tolist()]
    }
    
    # Model metrics
    model_metrics = {}
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH, "r") as f:
            model_metrics = json.load(f)
            
    return jsonify({
        "kpis": {
            "date": latest_date,
            "total_population": total_pop,
            "total_available_water": total_avail,
            "total_demand": total_demand,
            "total_shortage": total_shortage,
            "status": classify_shortage(total_shortage)
        },
        "area_chart": {
            "areas": areas_list,
            "available_water": available_by_area,
            "demand": demand_by_area,
            "shortage": shortage_by_area
        },
        "distribution_chart": {
            "labels": ["Sufficient (<= 0 L)", "Moderate Shortage (1 - 200k L)", "High Shortage (> 200k L)"],
            "counts": [sufficient_cnt, moderate_cnt, high_cnt],
            "colors": ["#10b981", "#f59e0b", "#ef4444"]
        },
        "trend_data": trend_data,
        "model_metrics": model_metrics,
        "disclaimer": DISCLAIMER_NOTE
    })


@app.route("/api/areas")
def api_areas():
    """API providing list of 10 areas and their default baseline values."""
    df = pd.read_csv(DATA_PATH)
    latest_date = df["date"].max()
    latest_df = df[df["date"] == latest_date].copy()
    model = get_model()
    features = latest_df[["population", "rainfall", "temperature", "available_water"]].astype(float)
    latest_df["predicted_demand"] = np.rint(model.predict(features)).astype(int)
    latest_df["predicted_shortage"] = latest_df["predicted_demand"] - latest_df["available_water"]

    areas = []
    for _, row in latest_df.iterrows():
        areas.append({
            "name": row["area"],
            "population": int(row["population"]),
            "rainfall": float(row["rainfall"]),
            "temperature": float(row["temperature"]),
            "available_water": int(row["available_water"]),
            "current_demand": int(row["predicted_demand"]),
            "current_shortage": int(row["predicted_shortage"])
        })
        
    return jsonify({
        "areas": areas,
        "disclaimer": DISCLAIMER_NOTE
    })


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """
    API endpoint for AI Prediction.
    Expects JSON:
    {
        "area": str,
        "population": int/float,
        "rainfall": float,
        "temperature": float,
        "available_water": int/float
    }
    """
    try:
        data = request.get_json(force=True)
        area_name = data.get("area", "Custom Area")
        population = float(data.get("population", 50000))
        rainfall = float(data.get("rainfall", 0.0))
        temperature = float(data.get("temperature", 28.0))
        available_water = float(data.get("available_water", 7000000))
        
        result = predict_single(
            area_name=area_name,
            population=population,
            rainfall=rainfall,
            temperature=temperature,
            available_water=available_water
        )
        
        result["disclaimer"] = DISCLAIMER_NOTE
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/allocation", methods=["GET", "POST"])
def api_allocation():
    """API endpoint for Water Allocation across all 10 areas."""
    try:
        custom_data = None
        if request.method == "POST":
            req_json = request.get_json(silent=True)
            if req_json and "areas" in req_json:
                custom_data = req_json["areas"]
                
        records, summary = compute_allocation_plan(custom_data)
        
        return jsonify({
            "records": records,
            "summary": summary,
            "disclaimer": DISCLAIMER_NOTE
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    ensure_data_and_model()
    print("=" * 60)
    print("AI-Based Water Allocation and Shortage Prediction System")
    print("Website running on: http://127.0.0.1:5000")
    print(f"Note: {DISCLAIMER_NOTE}")
    print("=" * 60)
    app.run(host="127.0.0.1", port=5000, debug=False)
