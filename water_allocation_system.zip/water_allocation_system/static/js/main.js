/**
 * AI-Based Water Allocation and Shortage Prediction System
 * Frontend Application Script
 */

document.addEventListener("DOMContentLoaded", () => {
    initNavigation();
    loadDashboardData();
    loadAreasForPrediction();
    loadAllocationData();
    initPredictionForm();
    initScenarioPresets();
    initAllocationFilters();
    initExportCSV();
});

// Global state
let areasListCache = [];
let allocationRecordsCache = [];
let charts = {
    areaBar: null,
    distDonut: null,
    trendLine: null
};

/* ==========================================================================
   Navigation Tabs
   ========================================================================== */
function initNavigation() {
    const navButtons = document.querySelectorAll(".nav-btn");
    const sections = document.querySelectorAll(".content-section");

    navButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-target");

            navButtons.forEach(b => b.classList.remove("active"));
            sections.forEach(s => s.classList.remove("active"));

            btn.classList.add("active");
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.add("active");
                window.scrollTo({ top: 0, behavior: "smooth" });
            }
        });
    });
}

/* ==========================================================================
   Formatters
   ========================================================================== */
function formatNumber(num) {
    if (num === null || num === undefined) return "--";
    return Number(num).toLocaleString();
}

function formatShortage(num) {
    const val = Number(num);
    const prefix = val > 0 ? "+" : "";
    return prefix + val.toLocaleString() + " L";
}

function getBadgeHtml(status) {
    if (status === "Sufficient") {
        return `<span class="badge badge-sufficient"><i class="fa-solid fa-circle-check"></i> Sufficient</span>`;
    } else if (status === "Moderate Shortage") {
        return `<span class="badge badge-moderate"><i class="fa-solid fa-triangle-exclamation"></i> Moderate Shortage</span>`;
    } else {
        return `<span class="badge badge-high"><i class="fa-solid fa-circle-xmark"></i> High Shortage</span>`;
    }
}

/* ==========================================================================
   Section 1: Dashboard
   ========================================================================== */
async function loadDashboardData() {
    try {
        const response = await fetch("/api/dashboard_data");
        const data = await response.json();

        // Update KPIs
        const kpis = data.kpis;
        document.getElementById("kpi-date").textContent = kpis.date;
        document.getElementById("kpi-population").textContent = formatNumber(kpis.total_population);
        document.getElementById("kpi-available").textContent = formatNumber(kpis.total_available_water) + " L";
        document.getElementById("kpi-available-mld").textContent = (kpis.total_available_water / 1e6).toFixed(1) + " Million Liters";
        
        document.getElementById("kpi-demand").textContent = formatNumber(kpis.total_demand) + " L";
        document.getElementById("kpi-demand-mld").textContent = (kpis.total_demand / 1e6).toFixed(1) + " Million Liters";

        const shortageEl = document.getElementById("kpi-shortage");
        shortageEl.textContent = formatShortage(kpis.total_shortage);

        const badgeEl = document.getElementById("kpi-status-badge");
        badgeEl.textContent = kpis.status;
        badgeEl.className = `badge badge-${kpis.status.toLowerCase().includes('sufficient') ? 'sufficient' : (kpis.status.toLowerCase().includes('moderate') ? 'moderate' : 'high')}`;

        // Render Charts
        renderAreaBarChart(data.area_chart);
        renderDistributionDonutChart(data.distribution_chart);
        renderTrendLineChart(data.trend_data);

    } catch (err) {
        console.error("Error loading dashboard data:", err);
    }
}

function renderAreaBarChart(chartData) {
    const ctx = document.getElementById("areaBarChart").getContext("2d");
    if (charts.areaBar) charts.areaBar.destroy();

    charts.areaBar = new Chart(ctx, {
        type: "bar",
        data: {
            labels: chartData.areas,
            datasets: [
                {
                    label: "Available Water (L)",
                    data: chartData.available_water,
                    backgroundColor: "rgba(2, 132, 199, 0.8)",
                    borderColor: "#0284c7",
                    borderWidth: 1,
                    borderRadius: 4
                },
                {
                    label: "Predicted Demand (L)",
                    data: chartData.demand,
                    backgroundColor: "rgba(6, 182, 212, 0.8)",
                    borderColor: "#06b6d4",
                    borderWidth: 1,
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: "index",
                intersect: false
            },
            plugins: {
                legend: {
                    position: "top",
                    labels: { font: { family: "Plus Jakarta Sans", weight: 600 } }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.dataset.label}: ${formatNumber(ctx.raw)} L`
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: (val) => (val / 1e6).toFixed(1) + "M L"
                    },
                    grid: { color: "#f1f5f9" }
                },
                x: {
                    grid: { display: false },
                    ticks: { maxRotation: 45, minRotation: 20 }
                }
            }
        }
    });
}

function renderDistributionDonutChart(distData) {
    const ctx = document.getElementById("distributionDonutChart").getContext("2d");
    if (charts.distDonut) charts.distDonut.destroy();

    charts.distDonut = new Chart(ctx, {
        type: "doughnut",
        data: {
            labels: distData.labels,
            datasets: [{
                data: distData.counts,
                backgroundColor: distData.colors,
                hoverOffset: 6,
                borderWidth: 2,
                borderColor: "#ffffff"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => ` ${ctx.label}: ${formatNumber(ctx.raw)} days (${((ctx.raw / 3650) * 100).toFixed(1)}%)`
                    }
                }
            },
            cutout: "68%"
        }
    });

    // Populate custom legend
    const legendEl = document.getElementById("distributionLegend");
    legendEl.innerHTML = distData.labels.map((label, idx) => `
        <div class="dist-item">
            <span><span class="dist-color" style="background-color: ${distData.colors[idx]}"></span>${label}</span>
            <strong>${formatNumber(distData.counts[idx])} (${((distData.counts[idx] / 3650) * 100).toFixed(1)}%)</strong>
        </div>
    `).join("");
}

function renderTrendLineChart(trendData) {
    const ctx = document.getElementById("trendLineChart").getContext("2d");
    if (charts.trendLine) charts.trendLine.destroy();

    charts.trendLine = new Chart(ctx, {
        type: "line",
        data: {
            labels: trendData.dates.map(d => d.slice(5)), // MM-DD
            datasets: [
                {
                    label: "Available Water (L)",
                    data: trendData.available_water,
                    borderColor: "#0284c7",
                    backgroundColor: "rgba(2, 132, 199, 0.1)",
                    borderWidth: 2.5,
                    tension: 0.3,
                    fill: true,
                    pointRadius: 2.5
                },
                {
                    label: "Water Demand (L)",
                    data: trendData.water_demand,
                    borderColor: "#06b6d4",
                    borderWidth: 2.5,
                    borderDash: [4, 4],
                    tension: 0.3,
                    fill: false,
                    pointRadius: 2.5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: "index",
                intersect: false
            },
            plugins: {
                legend: {
                    position: "top",
                    labels: { font: { family: "Plus Jakarta Sans", weight: 600 } }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.dataset.label}: ${formatNumber(ctx.raw)} L`
                    }
                }
            },
            scales: {
                y: {
                    ticks: {
                        callback: (val) => (val / 1e6).toFixed(1) + "M L"
                    },
                    grid: { color: "#f1f5f9" }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

/* ==========================================================================
   Section 2: AI Prediction
   ========================================================================== */
async function loadAreasForPrediction() {
    try {
        const response = await fetch("/api/areas");
        const data = await response.json();
        areasListCache = data.areas;

        const selectEl = document.getElementById("predict-area");
        selectEl.innerHTML = `<option value="" disabled selected>-- Select an Area (10 available) --</option>` +
            areasListCache.map(area => `<option value="${area.name}">${area.name} (Pop: ${formatNumber(area.population)})</option>`).join("");

        selectEl.addEventListener("change", () => {
            const selectedArea = areasListCache.find(a => a.name === selectEl.value);
            if (selectedArea) {
                document.getElementById("input-population").value = selectedArea.population;
                document.getElementById("input-rainfall").value = selectedArea.rainfall;
                document.getElementById("input-temperature").value = selectedArea.temperature;
                document.getElementById("input-available").value = selectedArea.available_water;
                document.getElementById("result-area-tag").textContent = selectedArea.name;
            }
        });

        // Auto-select first area
        if (areasListCache.length > 0) {
            selectEl.selectedIndex = 1;
            selectEl.dispatchEvent(new Event("change"));
        }
    } catch (err) {
        console.error("Error loading areas:", err);
    }
}

function initScenarioPresets() {
    const presetButtons = document.querySelectorAll(".btn-preset");
    presetButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const preset = btn.getAttribute("data-preset");
            const selectEl = document.getElementById("predict-area");
            const selectedArea = areasListCache.find(a => a.name === selectEl.value) || areasListCache[0];

            if (!selectedArea) return;

            if (preset === "normal") {
                document.getElementById("input-population").value = selectedArea.population;
                document.getElementById("input-rainfall").value = selectedArea.rainfall;
                document.getElementById("input-temperature").value = selectedArea.temperature;
                document.getElementById("input-available").value = selectedArea.available_water;
            } else if (preset === "heatwave") {
                document.getElementById("input-temperature").value = 39.5;
                document.getElementById("input-rainfall").value = 0.0;
                document.getElementById("input-available").value = Math.round(selectedArea.available_water * 0.95);
            } else if (preset === "monsoon") {
                document.getElementById("input-rainfall").value = 48.0;
                document.getElementById("input-temperature").value = 26.5;
                document.getElementById("input-available").value = Math.round(selectedArea.available_water * 1.15);
            } else if (preset === "drought") {
                document.getElementById("input-rainfall").value = 0.0;
                document.getElementById("input-available").value = Math.round(selectedArea.available_water * 0.80);
            }
        });
    });
}

function initPredictionForm() {
    const form = document.getElementById("prediction-form");
    const runBtn = document.getElementById("btn-run-prediction");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const areaName = document.getElementById("predict-area").value || "Custom Area";
        const payload = {
            area: areaName,
            population: parseFloat(document.getElementById("input-population").value),
            rainfall: parseFloat(document.getElementById("input-rainfall").value),
            temperature: parseFloat(document.getElementById("input-temperature").value),
            available_water: parseFloat(document.getElementById("input-available").value)
        };

        // Loading state
        runBtn.disabled = true;
        runBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Running Random Forest Prediction...`;

        try {
            const response = await fetch("/api/predict", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            const result = await response.json();
            displayPredictionResult(result);
        } catch (err) {
            console.error("Prediction error:", err);
            alert("Error running prediction: " + err.message);
        } finally {
            runBtn.disabled = false;
            runBtn.innerHTML = `<i class="fa-solid fa-bolt"></i> Run AI Water Demand Prediction`;
        }
    });
}

function displayPredictionResult(result) {
    document.getElementById("result-placeholder").style.display = "none";
    const detailsEl = document.getElementById("result-content");
    detailsEl.style.display = "flex";

    document.getElementById("result-area-tag").textContent = result.area;
    document.getElementById("res-demand").textContent = formatNumber(result.predicted_demand) + " L";
    document.getElementById("res-available").textContent = formatNumber(result.available_water) + " L";
    document.getElementById("res-shortage").textContent = formatShortage(result.shortage);
    
    // Status banner
    const bannerEl = document.getElementById("status-banner");
    const statusTitleEl = document.getElementById("status-title");
    const statusDescEl = document.getElementById("status-desc");
    const statusIconEl = document.getElementById("status-icon");

    statusTitleEl.textContent = result.status;
    statusDescEl.textContent = result.status_description;

    // Reset banner classes
    bannerEl.className = "result-status-banner";
    if (result.status === "Sufficient") {
        bannerEl.style.backgroundColor = "var(--status-sufficient-bg)";
        bannerEl.style.borderColor = "#a7f3d0";
        statusTitleEl.style.color = "#065f46";
        statusDescEl.style.color = "#047857";
        statusIconEl.innerHTML = `<i class="fa-solid fa-circle-check" style="color: var(--status-sufficient)"></i>`;
    } else if (result.status === "Moderate Shortage") {
        bannerEl.style.backgroundColor = "var(--status-moderate-bg)";
        bannerEl.style.borderColor = "#fde68a";
        statusTitleEl.style.color = "#92400e";
        statusDescEl.style.color = "#b45309";
        statusIconEl.innerHTML = `<i class="fa-solid fa-triangle-exclamation" style="color: var(--status-moderate)"></i>`;
    } else {
        bannerEl.style.backgroundColor = "var(--status-high-bg)";
        bannerEl.style.borderColor = "#fecaca";
        statusTitleEl.style.color = "#991b1b";
        statusDescEl.style.color = "#b91c1c";
        statusIconEl.innerHTML = `<i class="fa-solid fa-circle-xmark" style="color: var(--status-high)"></i>`;
    }

    // Supply coverage meter
    const coverage = Math.min(100, Math.max(0, result.coverage_percent));
    document.getElementById("res-coverage").textContent = result.coverage_percent + "%";
    const fillEl = document.getElementById("res-progress-fill");
    fillEl.style.width = coverage + "%";
    fillEl.style.background = result.coverage_percent >= 100 
        ? "linear-gradient(90deg, #10b981 0%, #06b6d4 100%)"
        : (result.coverage_percent >= 80 ? "linear-gradient(90deg, #f59e0b 0%, #fbbf24 100%)" : "linear-gradient(90deg, #ef4444 0%, #f87171 100%)");

    // Evaluation Rule Highlights
    document.getElementById("rule-item-sufficient").className = result.status === "Sufficient" ? "rule-active" : "";
    document.getElementById("rule-item-moderate").className = result.status === "Moderate Shortage" ? "rule-active" : "";
    document.getElementById("rule-item-high").className = result.status === "High Shortage" ? "rule-active" : "";
}

/* ==========================================================================
   Section 3: Water Allocation
   ========================================================================== */
async function loadAllocationData() {
    try {
        const response = await fetch("/api/allocation");
        const data = await response.json();
        allocationRecordsCache = data.records;

        // Populate summary cards
        const sum = data.summary;
        document.getElementById("alloc-sum-avail").textContent = formatNumber(sum.total_available_water) + " L";
        document.getElementById("alloc-sum-demand").textContent = formatNumber(sum.total_predicted_demand) + " L";
        document.getElementById("alloc-sum-deficit").textContent = formatNumber(sum.total_deficit) + " L";
        document.getElementById("alloc-sum-reallocated").textContent = formatNumber(sum.water_transferred) + " L";

        renderAllocationTable(allocationRecordsCache);
    } catch (err) {
        console.error("Error loading allocation data:", err);
    }
}

function renderAllocationTable(records) {
    const tbody = document.getElementById("allocation-table-body");
    if (!records || records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center py-4">No records found matching filter.</td></tr>`;
        return;
    }

    tbody.innerHTML = records.map((r, idx) => `
        <tr>
            <td class="mono-num">${idx + 1}</td>
            <td class="area-cell">${r.area}</td>
            <td class="mono-num">${formatNumber(r.population)}</td>
            <td class="mono-num">${formatNumber(r.available_water)}</td>
            <td class="mono-num">${formatNumber(r.predicted_demand)}</td>
            <td class="mono-num ${r.shortage > 0 ? 'text-danger' : 'text-success'}">
                ${formatShortage(r.shortage)}
            </td>
            <td>${getBadgeHtml(r.status)}</td>
            <td class="mono-num" style="color: var(--primary); font-weight: 700;">
                ${formatNumber(r.recommended_allocation)} L
            </td>
            <td>
                <span style="font-size: 0.8rem; font-weight: 600; color: #334155;">
                    <i class="fa-solid fa-arrow-right-arrow-left" style="color: var(--primary); font-size: 0.72rem;"></i> ${r.allocation_note}
                </span>
            </td>
        </tr>
    `).join("");
}

function initAllocationFilters() {
    const filterBtns = document.querySelectorAll(".filter-btn");
    const searchInput = document.getElementById("table-search-input");

    function applyFilters() {
        const activeBtn = document.querySelector(".filter-btn.active");
        const filterVal = activeBtn ? activeBtn.getAttribute("data-filter") : "all";
        const searchVal = searchInput.value.toLowerCase().trim();

        let filtered = allocationRecordsCache;

        if (filterVal !== "all") {
            filtered = filtered.filter(r => r.status === filterVal);
        }

        if (searchVal) {
            filtered = filtered.filter(r => r.area.toLowerCase().includes(searchVal));
        }

        renderAllocationTable(filtered);
    }

    filterBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            filterBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            applyFilters();
        });
    });

    searchInput.addEventListener("input", applyFilters);

    document.getElementById("btn-refresh-allocation").addEventListener("click", () => {
        loadAllocationData();
    });
}

function initExportCSV() {
    document.getElementById("btn-export-csv").addEventListener("click", () => {
        if (!allocationRecordsCache || allocationRecordsCache.length === 0) return;

        const headers = ["Area", "Population", "Available Water (L)", "Predicted Demand (L)", "Shortage (L)", "Status", "Recommended Allocation (L)", "Allocation Outcome"];
        const rows = allocationRecordsCache.map(r => [
            `"${r.area}"`,
            r.population,
            r.available_water,
            r.predicted_demand,
            r.shortage,
            `"${r.status}"`,
            r.recommended_allocation,
            `"${r.allocation_note}"`
        ]);

        let csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `water_allocation_plan_${new Date().toISOString().slice(0, 10)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
}
