"""
AI-Based Water Allocation and Shortage Prediction System
Machine Learning Model Training - Random Forest Regression

Inputs (Features):
- population
- rainfall
- temperature
- available_water

Target:
- water_demand

Shortage Formula:
shortage = predicted_water_demand - available_water

Status Rules:
- shortage <= 0        -> "Sufficient"
- 0 < shortage <= 200000 -> "Moderate Shortage"
- shortage > 200000     -> "High Shortage"
"""

import os
import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

DATA_PATH = "data/water_data.csv"
MODEL_PATH = "model/water_demand_rf.joblib"
METRICS_PATH = "model/model_metrics.json"

FEATURE_COLS = ["population", "rainfall", "temperature", "available_water"]
TARGET_COL = "water_demand"


def classify_shortage(shortage_val):
    """Classify shortage value according to project specification."""
    if shortage_val <= 0:
        return "Sufficient"
    elif shortage_val <= 200000:
        return "Moderate Shortage"
    else:
        return "High Shortage"


def train_model():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Data file not found at {DATA_PATH}. Run generate_dataset.py first.")
        
    df = pd.read_csv(DATA_PATH)
    print(f"Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    
    X = df[FEATURE_COLS]
    y = df[TARGET_COL]
    
    # Train / Test Split (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    
    print(f"Training Random Forest Regressor on {len(X_train)} samples...")
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=16,
        min_samples_split=4,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    
    # Predictions & Evaluation
    y_pred_test = model.predict(X_test)
    r2 = r2_score(y_test, y_pred_test)
    mae = mean_absolute_error(y_test, y_pred_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
    
    print("=== Model Evaluation ===")
    print(f"R² Score: {r2:.4f}")
    print(f"MAE: {mae:,.2f} Liters")
    print(f"RMSE: {rmse:,.2f} Liters")
    
    # Feature importances
    feature_importances = dict(zip(FEATURE_COLS, [round(float(imp), 4) for imp in model.feature_importances_]))
    print(f"Feature Importances: {feature_importances}")
    
    # Save model and metadata
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"Model saved to {MODEL_PATH}")
    
    metrics = {
        "model_type": "RandomForestRegressor",
        "n_estimators": 100,
        "features": FEATURE_COLS,
        "target": TARGET_COL,
        "r2_score": round(float(r2), 4),
        "mae": round(float(mae), 2),
        "rmse": round(float(rmse), 2),
        "feature_importances": feature_importances,
        "total_samples": len(df),
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "disclaimer": "Dataset is synthetically generated for project demonstration."
    }
    
    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)
        
    print(f"Metrics saved to {METRICS_PATH}")
    return model, metrics


if __name__ == "__main__":
    train_model()
