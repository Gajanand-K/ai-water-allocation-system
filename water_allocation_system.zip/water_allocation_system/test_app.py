"""
Comprehensive Test Script for AI-Based Water Allocation and Shortage Prediction System
"""

import json
import pandas as pd
from app import app, DATA_PATH, MODEL_PATH
from water_allocation import get_shortage_status, predict_single, compute_allocation_plan

def test_system():
    print("==================================================")
    print("Testing Water Allocation & Shortage System")
    print("==================================================")

    # 1. Dataset Verification
    df = pd.read_csv(DATA_PATH)
    assert len(df) == 3650, f"Expected 3650 rows, got {len(df)}"
    assert len(df["area"].unique()) == 10, f"Expected 10 areas, got {len(df['area'].unique())}"
    expected_cols = ["date", "area", "population", "rainfall", "temperature", "available_water", "water_demand", "shortage"]
    for col in expected_cols:
        assert col in df.columns, f"Missing column {col}"
    print(f"[OK] Dataset verified: 3,650 rows, 10 areas, all 8 required columns present.")

    # 2. Status Classification Rules
    assert get_shortage_status(-50000)["status"] == "Sufficient"
    assert get_shortage_status(0)["status"] == "Sufficient"
    assert get_shortage_status(50000)["status"] == "Moderate Shortage"
    assert get_shortage_status(200000)["status"] == "Moderate Shortage"
    assert get_shortage_status(200001)["status"] == "High Shortage"
    assert get_shortage_status(500000)["status"] == "High Shortage"
    print("[OK] Shortage status logic verified for Sufficient, Moderate Shortage, and High Shortage.")

    # 3. Flask Test Client
    client = app.test_client()

    # Route: /
    res_home = client.get("/")
    assert res_home.status_code == 200
    home_html = res_home.data.decode("utf-8")
    assert "AI-Based Water Allocation and Shortage Prediction System" in home_html
    assert "Dataset is synthetically generated for project demonstration." in home_html
    print("[OK] Web homepage (GET /) verified with required title and disclaimer note.")

    # Route: /api/dashboard_data
    res_dash = client.get("/api/dashboard_data")
    assert res_dash.status_code == 200
    dash_json = json.loads(res_dash.data)
    assert "kpis" in dash_json
    assert "area_chart" in dash_json
    assert "distribution_chart" in dash_json
    assert "trend_data" in dash_json
    print(f"[OK] Dashboard API (GET /api/dashboard_data) verified: Pop={dash_json['kpis']['total_population']:,}, Avail={dash_json['kpis']['total_available_water']:,} L, Demand={dash_json['kpis']['total_demand']:,} L")

    # Route: /api/areas
    res_areas = client.get("/api/areas")
    assert res_areas.status_code == 200
    areas_json = json.loads(res_areas.data)
    assert len(areas_json["areas"]) == 10
    print(f"[OK] Areas API (GET /api/areas) verified with all 10 areas.")

    # Route: /api/predict (Test Sufficient, Moderate Shortage, High Shortage)
    # 1) Sufficient test (Large available water)
    res_pred1 = client.post("/api/predict", json={
        "area": "Lakeview",
        "population": 40000,
        "rainfall": 15.0,
        "temperature": 24.0,
        "available_water": 8000000
    })
    assert res_pred1.status_code == 200
    p1 = json.loads(res_pred1.data)
    print(f"[OK] AI Prediction (Sufficient scenario): Demand={p1['predicted_demand']:,} L, Avail={p1['available_water']:,} L -> Shortage={p1['shortage']:,} L [{p1['status']}]")
    assert p1["status"] == "Sufficient"

    # 2) Moderate Shortage test (Deficit between 1 and 200,000)
    pred_res = predict_single("North Hills", 38000, 2.0, 27.0, 5650000)
    target_avail_moderate = pred_res["predicted_demand"] - 75000
    res_pred2 = client.post("/api/predict", json={
        "area": "North Hills",
        "population": 38000,
        "rainfall": 2.0,
        "temperature": 27.0,
        "available_water": target_avail_moderate
    })
    assert res_pred2.status_code == 200
    p2 = json.loads(res_pred2.data)
    print(f"[OK] AI Prediction (Moderate Shortage scenario): Demand={p2['predicted_demand']:,} L, Avail={p2['available_water']:,} L -> Shortage={p2['shortage']:,} L [{p2['status']}]")
    assert p2["status"] == "Moderate Shortage"

    # 3) High Shortage test (Deficit > 200,000)
    res_pred3 = client.post("/api/predict", json={
        "area": "Central Metro",
        "population": 120000,
        "rainfall": 0.0,
        "temperature": 38.0,
        "available_water": 12000000
    })
    assert res_pred3.status_code == 200
    p3 = json.loads(res_pred3.data)
    print(f"[OK] AI Prediction (High Shortage scenario): Demand={p3['predicted_demand']:,} L, Avail={p3['available_water']:,} L -> Shortage={p3['shortage']:,} L [{p3['status']}]")
    assert p3["status"] == "High Shortage"

    # Route: /api/allocation
    res_alloc = client.get("/api/allocation")
    assert res_alloc.status_code == 200
    alloc_json = json.loads(res_alloc.data)
    records = alloc_json["records"]
    assert len(records) == 10
    print(f"[OK] Water Allocation API (GET /api/allocation) verified: 10 areas evaluated with recommended allocations.")
    for r in records[:3]:
        print(f"   * {r['area']}: Avail={r['available_water']:,} L | Demand={r['predicted_demand']:,} L | Shortage={r['shortage']:,} L [{r['status']}] -> Rec. Allocation={r['recommended_allocation']:,} L")

    print("==================================================")
    print("ALL TESTS PASSED SUCCESSFULLY! 100% VERIFIED.")
    print("==================================================")

if __name__ == "__main__":
    test_system()
